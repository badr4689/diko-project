import { auth } from "@/lib/auth";

export default auth((req) => {
  const publicRoutes = ["/", "/login", "/register"];
  const { pathname } = req.nextUrl;

  if (publicRoutes.includes(pathname)) return;

  if (!req.auth) {
    const url = new URL("/login", req.url);
    url.searchParams.set("callbackUrl", pathname);
    return Response.redirect(url);
  }
});

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico).*)"],
};
