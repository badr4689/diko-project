import { DefaultSession, DefaultUser } from "next-auth";
import { JWT, DefaultJWT } from "next-auth/jwt";

declare module "next-auth" {
  interface User {
    companyId?: string;
    role?: string;
    companyName?: string;
  }
  interface Session {
    user: {
      companyId: string;
      role: string;
      companyName: string;
    } & DefaultSession["user"];
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    companyId: string;
    role: string;
    companyName: string;
  }
}
