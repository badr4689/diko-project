"use client";

import { useSession, signOut } from "next-auth/react";
import { LogOut, User, Bell } from "lucide-react";

export function Header() {
  const { data: session } = useSession();

  return (
    <header className="h-16 bg-zinc-900 border-b border-zinc-800 flex items-center justify-between px-6">
      <div>
        <h1 className="text-white text-lg font-semibold">
          {session?.user?.companyName || "diko"}
        </h1>
      </div>
      <div className="flex items-center gap-4">
        <button className="w-9 h-9 rounded-lg bg-zinc-800 flex items-center justify-center text-zinc-400 hover:text-zinc-200 transition-colors relative">
          <Bell className="w-4 h-4" />
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-indigo-500 rounded-full text-[10px] flex items-center justify-center text-white font-medium">
            3
          </span>
        </button>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
            <User className="w-4 h-4 text-white" />
          </div>
          <div className="text-sm">
            <p className="text-zinc-200 font-medium">{session?.user?.name}</p>
            <p className="text-zinc-500 text-xs capitalize">{session?.user?.role}</p>
          </div>
        </div>
        <button
          onClick={() => signOut()}
          className="text-zinc-500 hover:text-red-400 transition-colors p-2"
          title="Sign out"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
}
