"use client";

import { useState, useCallback } from "react";
import {
  DndContext,
  DragOverlay,
  closestCorners,
  PointerSensor,
  useSensor,
  useSensors,
  DragStartEvent,
  DragEndEvent,
} from "@dnd-kit/core";
import { SortableContext, useSortable, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { GripVertical, Plus } from "lucide-react";

const STAGES = [
  { id: "new", label: "New", color: "bg-blue-500/10 border-blue-500/30 text-blue-400" },
  { id: "qualified", label: "Qualified", color: "bg-indigo-500/10 border-indigo-500/30 text-indigo-400" },
  { id: "negotiation", label: "Negotiation", color: "bg-amber-500/10 border-amber-500/30 text-amber-400" },
  { id: "won", label: "Won", color: "bg-emerald-500/10 border-emerald-500/30 text-emerald-400" },
  { id: "lost", label: "Lost", color: "bg-red-500/10 border-red-500/30 text-red-400" },
];

interface Deal {
  id: string;
  title: string;
  amount: number;
  stage: string;
  customer?: { name: string };
  assigned?: { fullName: string };
}

interface KanbanBoardProps {
  deals: Deal[];
  onStageChange: (dealId: string, newStage: string) => void;
  onGenerateInvoice?: (deal: Deal) => void;
}

function SortableDealCard({ deal, onGenerateInvoice }: { deal: Deal; onGenerateInvoice?: (deal: Deal) => void }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: deal.id,
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="bg-zinc-800 rounded-lg border border-zinc-700 p-3 cursor-grab active:cursor-grabbing hover:border-zinc-600 transition-colors"
    >
      <div className="flex items-start gap-2">
        <button {...attributes} {...listeners} className="mt-0.5 text-zinc-600 hover:text-zinc-400">
          <GripVertical className="w-4 h-4" />
        </button>
        <div className="flex-1 min-w-0">
          <p className="text-zinc-200 text-sm font-medium truncate">{deal.title}</p>
          <p className="text-indigo-400 text-sm font-semibold mt-1">
            ${deal.amount.toLocaleString()}
          </p>
          {deal.customer && (
            <p className="text-zinc-500 text-xs mt-1">{deal.customer.name}</p>
          )}
          {deal.stage === "won" && onGenerateInvoice && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onGenerateInvoice(deal);
              }}
              className="mt-2 w-full text-xs bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-md py-1.5 hover:bg-emerald-500/20 transition-colors"
            >
              Generate Invoice
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function KanbanColumn({
  stage,
  deals,
  onGenerateInvoice,
}: {
  stage: (typeof STAGES)[0];
  deals: Deal[];
  onGenerateInvoice?: (deal: Deal) => void;
}) {
  return (
    <div className="flex-1 min-w-[250px] bg-zinc-900/50 rounded-xl border border-zinc-800 p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className={`px-2.5 py-1 rounded-md text-xs font-medium border ${stage.color}`}>
            {stage.label}
          </div>
          <span className="text-zinc-500 text-sm">{deals.length}</span>
        </div>
      </div>
      <SortableContext items={deals.map((d) => d.id)} strategy={verticalListSortingStrategy}>
        <div className="space-y-2 min-h-[100px]">
          {deals.map((deal) => (
            <SortableDealCard key={deal.id} deal={deal} onGenerateInvoice={onGenerateInvoice} />
          ))}
        </div>
      </SortableContext>
    </div>
  );
}

export function KanbanBoard({ deals, onStageChange, onGenerateInvoice }: KanbanBoardProps) {
  const [activeDeal, setActiveDeal] = useState<Deal | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } })
  );

  const handleDragStart = useCallback((event: DragStartEvent) => {
    const deal = deals.find((d) => d.id === event.active.id);
    if (deal) setActiveDeal(deal);
  }, [deals]);

  const handleDragEnd = useCallback((event: DragEndEvent) => {
    const { active, over } = event;
    if (!over) return;

    const dealId = active.id as string;
    const overStage = over.id as string;

    if (STAGES.some((s) => s.id === overStage) && overStage !== deals.find((d) => d.id === dealId)?.stage) {
      onStageChange(dealId, overStage);
    }
    setActiveDeal(null);
  }, [deals, onStageChange]);

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCorners}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
    >
      <div className="flex gap-4 overflow-x-auto pb-4">
        {STAGES.map((stage) => (
          <KanbanColumn
            key={stage.id}
            stage={stage}
            deals={deals.filter((d) => d.stage === stage.id)}
            onGenerateInvoice={onGenerateInvoice}
          />
        ))}
      </div>
      <DragOverlay>
        {activeDeal ? (
          <div className="bg-zinc-800 rounded-lg border border-indigo-500/50 p-3 shadow-xl">
            <p className="text-zinc-200 text-sm font-medium">{activeDeal.title}</p>
            <p className="text-indigo-400 text-sm font-semibold mt-1">
              ${activeDeal.amount.toLocaleString()}
            </p>
          </div>
        ) : null}
      </DragOverlay>
    </DndContext>
  );
}
