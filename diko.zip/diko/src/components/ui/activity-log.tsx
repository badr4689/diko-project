import { Activity, ArrowRight } from "lucide-react";
import { formatDate } from "@/lib/utils";

interface ActivityItem {
  id: string;
  action: string;
  entity: string;
  details?: string;
  createdAt: string;
}

export function ActivityLog({ activities }: { activities: ActivityItem[] }) {
  return (
    <div className="bg-zinc-900 rounded-xl border border-zinc-800 p-6">
      <h3 className="text-white font-semibold mb-4">Recent Activity</h3>
      <div className="space-y-3">
        {activities.length === 0 ? (
          <p className="text-zinc-500 text-sm">No recent activity</p>
        ) : (
          activities.map((activity) => (
            <div key={activity.id} className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Activity className="w-4 h-4 text-indigo-400" />
              </div>
              <div>
                <p className="text-zinc-300 text-sm">
                  {activity.action}{" "}
                  <span className="text-indigo-400">{activity.entity}</span>
                </p>
                {activity.details && (
                  <p className="text-zinc-500 text-xs mt-0.5">{activity.details}</p>
                )}
                <p className="text-zinc-600 text-xs mt-0.5">
                  {formatDate(activity.createdAt)}
                </p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
