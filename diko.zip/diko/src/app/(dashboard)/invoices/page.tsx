"use client";

import { useState, useEffect, useCallback } from "react";
import { Modal } from "@/components/ui/modal";
import { Plus, Search, Trash2, X, Check } from "lucide-react";
import { formatCurrency, formatDate } from "@/lib/utils";

interface Customer {
  id: string;
  name: string;
}

interface Product {
  id: string;
  name: string;
  salePrice: number;
}

interface InvoiceItem {
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
}

interface Invoice {
  id: string;
  invoiceNumber: string;
  customer?: { name: string } | null;
  totalAmount: number;
  status: string;
  dueDate: string;
  createdAt: string;
}

export default function InvoicesPage() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [showCreateModal, setShowCreateModal] = useState(false);

  const [form, setForm] = useState({
    customerId: "",
    dueDate: "",
    taxRate: "0",
  });
  const [items, setItems] = useState<InvoiceItem[]>([]);

  const fetchData = useCallback(async () => {
    try {
      const [invRes, custRes, prodRes] = await Promise.all([
        fetch("/api/invoices"),
        fetch("/api/customers"),
        fetch("/api/products"),
      ]);
      if (invRes.ok) setInvoices(await invRes.json());
      if (custRes.ok) setCustomers(await custRes.json());
      if (prodRes.ok) setProducts(await prodRes.json());
    } catch (err) {
      console.error("Failed to fetch data", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const addItem = () => {
    setItems(prev => [...prev, { productId: "", productName: "", quantity: 1, unitPrice: 0, totalPrice: 0 }]);
  };

  const removeItem = (index: number) => {
    setItems(prev => prev.filter((_, i) => i !== index));
  };

  const updateItem = (index: number, field: keyof InvoiceItem, value: string | number) => {
    setItems(prev => {
      const updated = [...prev];
      if (field === "productId") {
        const product = products.find(p => p.id === value);
        updated[index] = {
          ...updated[index],
          productId: value as string,
          productName: product?.name || "",
          unitPrice: product?.salePrice || 0,
          totalPrice: product ? (product.salePrice * updated[index].quantity) : 0,
        };
      } else if (field === "quantity") {
        const qty = parseInt(value as string) || 0;
        updated[index] = {
          ...updated[index],
          quantity: qty,
          totalPrice: qty * updated[index].unitPrice,
        };
      } else if (field === "unitPrice") {
        const price = parseFloat(value as string) || 0;
        updated[index] = {
          ...updated[index],
          unitPrice: price,
          totalPrice: price * updated[index].quantity,
        };
      }
      return updated;
    });
  };

  const subtotal = items.reduce((sum, item) => sum + item.totalPrice, 0);
  const taxRate = parseFloat(form.taxRate) || 0;
  const taxAmount = subtotal * (taxRate / 100);
  const totalAmount = subtotal + taxAmount;

  const handleCreateInvoice = async () => {
    const res = await fetch("/api/invoices", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        customerId: form.customerId,
        dueDate: form.dueDate,
        taxRate: taxRate,
        items: items.map(item => ({
          productId: item.productId,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
        })),
      }),
    });
    if (res.ok) {
      const newInvoice = await res.json();
      setInvoices(prev => [newInvoice, ...prev]);
      setShowCreateModal(false);
      setForm({ customerId: "", dueDate: "", taxRate: "0" });
      setItems([]);
    }
  };

  const markAsPaid = async (id: string) => {
    const res = await fetch("/api/invoices", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, status: "paid" }),
    });
    if (res.ok) {
      setInvoices(prev => prev.map(inv => inv.id === id ? { ...inv, status: "paid" } : inv));
    }
  };

  const deleteInvoice = async (id: string) => {
    if (!confirm("Delete this invoice?")) return;
    const res = await fetch(`/api/invoices?id=${id}`, { method: "DELETE" });
    if (res.ok) setInvoices(prev => prev.filter(inv => inv.id !== id));
  };

  const filteredInvoices = invoices.filter(inv =>
    inv.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
    inv.customer?.name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const statusColors: Record<string, string> = {
    draft: "bg-zinc-500/10 text-zinc-400",
    sent: "bg-blue-500/10 text-blue-400",
    paid: "bg-emerald-500/10 text-emerald-400",
    overdue: "bg-red-500/10 text-red-400",
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Invoices</h1>
          <p className="text-zinc-500 text-sm mt-1">Create and manage invoices</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="bg-indigo-500 hover:bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
        >
          <Plus className="w-4 h-4" /> Create Invoice
        </button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
        <input
          type="text"
          placeholder="Search invoices..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full max-w-md pl-10 pr-4 py-2 bg-zinc-900 border border-zinc-800 rounded-lg text-white placeholder:text-zinc-600 focus:outline-none focus:border-indigo-500/50 text-sm"
        />
      </div>

      <div className="bg-zinc-900 rounded-xl border border-zinc-800 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-zinc-800">
              <th className="text-left py-3 px-4 text-zinc-400 text-xs font-medium uppercase tracking-wider">Invoice</th>
              <th className="text-left py-3 px-4 text-zinc-400 text-xs font-medium uppercase tracking-wider">Customer</th>
              <th className="text-right py-3 px-4 text-zinc-400 text-xs font-medium uppercase tracking-wider">Amount</th>
              <th className="text-left py-3 px-4 text-zinc-400 text-xs font-medium uppercase tracking-wider">Status</th>
              <th className="text-left py-3 px-4 text-zinc-400 text-xs font-medium uppercase tracking-wider">Due Date</th>
              <th className="text-right py-3 px-4 text-zinc-400 text-xs font-medium uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredInvoices.map((invoice) => (
              <tr key={invoice.id} className="border-b border-zinc-800/50 hover:bg-zinc-800/30 transition-colors">
                <td className="py-3 px-4">
                  <span className="text-white text-sm font-mono">{invoice.invoiceNumber}</span>
                </td>
                <td className="py-3 px-4 text-zinc-400 text-sm">{invoice.customer?.name || "—"}</td>
                <td className="py-3 px-4 text-zinc-200 text-sm text-right font-medium">
                  {formatCurrency(invoice.totalAmount)}
                </td>
                <td className="py-3 px-4">
                  <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[invoice.status] || "bg-zinc-500/10 text-zinc-400"}`}>
                    {invoice.status}
                  </span>
                </td>
                <td className="py-3 px-4 text-zinc-400 text-sm">{formatDate(invoice.dueDate)}</td>
                <td className="py-3 px-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    {invoice.status !== "paid" && (
                      <button
                        onClick={() => markAsPaid(invoice.id)}
                        className="text-zinc-600 hover:text-emerald-400 transition-colors"
                        title="Mark as paid"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      onClick={() => deleteInvoice(invoice.id)}
                      className="text-zinc-600 hover:text-red-400 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {filteredInvoices.length === 0 && (
              <tr>
                <td colSpan={6} className="py-8 text-center text-zinc-500 text-sm">
                  No invoices found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Create Invoice Modal */}
      <Modal isOpen={showCreateModal} onClose={() => { setShowCreateModal(false); setItems([]); }} title="Create Invoice">
        <div className="space-y-4">
          <div>
            <label className="block text-sm text-zinc-300 mb-1">Customer</label>
            <select
              value={form.customerId}
              onChange={(e) => setForm(p => ({ ...p, customerId: e.target.value }))}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500/50"
            >
              <option value="">Select customer</option>
              {customers.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-zinc-300 mb-1">Due Date</label>
              <input
                type="date"
                value={form.dueDate}
                onChange={(e) => setForm(p => ({ ...p, dueDate: e.target.value }))}
                className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500/50"
              />
            </div>
            <div>
              <label className="block text-sm text-zinc-300 mb-1">Tax Rate (%)</label>
              <input
                type="number"
                value={form.taxRate}
                onChange={(e) => setForm(p => ({ ...p, taxRate: e.target.value }))}
                className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500/50"
                placeholder="0"
                step="0.1"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm text-zinc-300">Items</label>
              <button
                onClick={addItem}
                className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
              >
                <Plus className="w-3 h-3" /> Add Item
              </button>
            </div>
            <div className="space-y-2">
              {items.map((item, index) => (
                <div key={index} className="flex items-center gap-2">
                  <select
                    value={item.productId}
                    onChange={(e) => updateItem(index, "productId", e.target.value)}
                    className="flex-1 px-2 py-1.5 bg-zinc-800 border border-zinc-700 rounded text-white text-xs focus:outline-none focus:border-indigo-500/50"
                  >
                    <option value="">Select product</option>
                    {products.map(p => (
                      <option key={p.id} value={p.id}>{p.name} (${p.salePrice})</option>
                    ))}
                  </select>
                  <input
                    type="number"
                    value={item.quantity}
                    onChange={(e) => updateItem(index, "quantity", e.target.value)}
                    className="w-16 px-2 py-1.5 bg-zinc-800 border border-zinc-700 rounded text-white text-xs text-center focus:outline-none focus:border-indigo-500/50"
                    placeholder="Qty"
                    min="1"
                  />
                  <input
                    type="number"
                    value={item.unitPrice}
                    onChange={(e) => updateItem(index, "unitPrice", e.target.value)}
                    className="w-20 px-2 py-1.5 bg-zinc-800 border border-zinc-700 rounded text-white text-xs text-center focus:outline-none focus:border-indigo-500/50"
                    placeholder="Price"
                    step="0.01"
                  />
                  <span className="text-zinc-300 text-xs w-16 text-right">
                    ${item.totalPrice.toFixed(2)}
                  </span>
                  <button onClick={() => removeItem(index)} className="text-zinc-600 hover:text-red-400">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
              {items.length === 0 && (
                <p className="text-zinc-500 text-xs">No items added yet</p>
              )}
            </div>
          </div>

          <div className="border-t border-zinc-800 pt-3 space-y-1">
            <div className="flex justify-between text-sm text-zinc-400">
              <span>Subtotal</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm text-zinc-400">
              <span>Tax ({taxRate}%)</span>
              <span>${taxAmount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm text-white font-semibold">
              <span>Total</span>
              <span>${totalAmount.toFixed(2)}</span>
            </div>
          </div>

          <button
            onClick={handleCreateInvoice}
            disabled={!form.customerId || items.length === 0}
            className="w-full bg-indigo-500 hover:bg-indigo-600 disabled:opacity-50 disabled:cursor-not-allowed text-white py-2 rounded-lg text-sm font-medium transition-colors"
          >
            Create Invoice
          </button>
        </div>
      </Modal>
    </div>
  );
}
