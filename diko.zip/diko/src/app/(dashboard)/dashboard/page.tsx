import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { DashboardClient } from "./client";

export default async function DashboardPage() {
  const session = await auth();
  if (!session?.user) redirect("/login");

  const companyId = session.user.companyId;

  const now = new Date();
  const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  const monthlyRevenueResult = await prisma.invoice.aggregate({
    where: { companyId, status: "paid", createdAt: { gte: firstDayOfMonth } },
    _sum: { totalAmount: true },
  });
  const monthlyRevenue = monthlyRevenueResult._sum.totalAmount || 0;

  const activeDeals = await prisma.deal.count({
    where: { companyId, stage: { notIn: ["won", "lost"] } },
  });

  const products = await prisma.product.findMany({
    where: { companyId },
    select: { quantityInStock: true, reorderLevel: true },
  });
  const lowStockItems = products.filter(p => p.quantityInStock <= p.reorderLevel).length;

  const pendingInvoicesResult = await prisma.invoice.aggregate({
    where: { companyId, status: { in: ["sent", "overdue"] } },
    _sum: { totalAmount: true },
  });
  const pendingInvoices = pendingInvoicesResult._sum.totalAmount || 0;

  const sixMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 5, 1);
  const paidInvoices = await prisma.invoice.findMany({
    where: { companyId, status: "paid", createdAt: { gte: sixMonthsAgo } },
    select: { totalAmount: true, createdAt: true },
  });

  const monthlyData: Record<string, number> = {};
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const key = d.toLocaleString("en-US", { month: "short", year: "2-digit" });
    monthlyData[key] = 0;
  }
  for (const inv of paidInvoices) {
    const key = inv.createdAt.toLocaleString("en-US", { month: "short", year: "2-digit" });
    monthlyData[key] = (monthlyData[key] || 0) + inv.totalAmount;
  }
  const revenueData = Object.entries(monthlyData).map(([month, revenue]) => ({ month, revenue }));

  const recentActivities = await prisma.activity.findMany({
    where: { companyId },
    orderBy: { createdAt: "desc" },
    take: 5,
  });

  return (
    <DashboardClient
      monthlyRevenue={monthlyRevenue}
      activeDeals={activeDeals}
      lowStockItems={lowStockItems}
      pendingInvoices={pendingInvoices}
      revenueData={revenueData}
      recentActivities={recentActivities.map(a => ({
        id: a.id,
        action: a.action,
        entity: a.entity,
        details: a.details || undefined,
        createdAt: a.createdAt.toISOString(),
      }))}
    />
  );
}
