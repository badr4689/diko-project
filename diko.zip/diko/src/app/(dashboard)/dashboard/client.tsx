"use client";

import { StatCard } from "@/components/ui/stat-card";
import { RevenueChart } from "@/components/ui/revenue-chart";
import { ActivityLog } from "@/components/ui/activity-log";
import { DollarSign, TrendingUp, Package, Clock } from "lucide-react";
import { formatCurrency } from "@/lib/utils";

interface DashboardClientProps {
  monthlyRevenue: number;
  activeDeals: number;
  lowStockItems: number;
  pendingInvoices: number;
  revenueData: { month: string; revenue: number }[];
  recentActivities: { id: string; action: string; entity: string; details?: string; createdAt: string }[];
}

export function DashboardClient({
  monthlyRevenue,
  activeDeals,
  lowStockItems,
  pendingInvoices,
  revenueData,
  recentActivities,
}: DashboardClientProps) {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Dashboard</h1>
        <p className="text-zinc-500 text-sm mt-1">
          Overview of your business performance
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Monthly Revenue"
          value={formatCurrency(monthlyRevenue)}
          icon={DollarSign}
          trend={12}
        />
        <StatCard
          title="Active Deals"
          value={activeDeals}
          icon={TrendingUp}
          trend={8}
        />
        <StatCard
          title="Low Stock Items"
          value={lowStockItems}
          icon={Package}
          variant={lowStockItems > 0 ? "warning" : "default"}
        />
        <StatCard
          title="Pending Invoices"
          value={formatCurrency(pendingInvoices)}
          icon={Clock}
          variant={pendingInvoices > 0 ? "danger" : "default"}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <RevenueChart data={revenueData} />
        </div>
        <ActivityLog activities={recentActivities} />
      </div>
    </div>
  );
}
