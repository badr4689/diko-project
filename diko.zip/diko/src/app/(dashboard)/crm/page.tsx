"use client";

import { useState, useEffect, useCallback } from "react";
import { KanbanBoard } from "@/components/ui/kanban-board";
import { Modal } from "@/components/ui/modal";
import { Plus, Search, Users, KanbanSquare, Trash2 } from "lucide-react";

interface Customer {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  companyName: string | null;
  status: string;
  createdAt: string;
}

interface Deal {
  id: string;
  title: string;
  amount: number;
  stage: string;
  customerId: string | null;
  assignedTo: string | null;
  customer?: { name: string } | null;
  assigned?: { fullName: string } | null;
}

export default function CrmPage() {
  const [activeTab, setActiveTab] = useState<"customers" | "kanban">("customers");
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [deals, setDeals] = useState<Deal[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [showCustomerModal, setShowCustomerModal] = useState(false);
  const [showDealModal, setShowDealModal] = useState(false);
  const [loading, setLoading] = useState(true);

  const [customerForm, setCustomerForm] = useState({ name: "", email: "", phone: "", companyName: "" });
  const [dealForm, setDealForm] = useState({ title: "", amount: "", customerId: "" });

  const fetchData = useCallback(async () => {
    try {
      const [custRes, dealRes] = await Promise.all([
        fetch("/api/customers"),
        fetch("/api/deals"),
      ]);
      if (custRes.ok) setCustomers(await custRes.json());
      if (dealRes.ok) setDeals(await dealRes.json());
    } catch (err) {
      console.error("Failed to fetch CRM data", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const addCustomer = async () => {
    const res = await fetch("/api/customers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(customerForm),
    });
    if (res.ok) {
      const newCustomer = await res.json();
      setCustomers(prev => [...prev, newCustomer]);
      setShowCustomerModal(false);
      setCustomerForm({ name: "", email: "", phone: "", companyName: "" });
    }
  };

  const deleteCustomer = async (id: string) => {
    if (!confirm("Delete this customer?")) return;
    const res = await fetch(`/api/customers?id=${id}`, { method: "DELETE" });
    if (res.ok) setCustomers(prev => prev.filter(c => c.id !== id));
  };

  const addDeal = async () => {
    const res = await fetch("/api/deals", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: dealForm.title,
        amount: parseFloat(dealForm.amount) || 0,
        customerId: dealForm.customerId || null,
      }),
    });
    if (res.ok) {
      const newDeal = await res.json();
      setDeals(prev => [...prev, newDeal]);
      setShowDealModal(false);
      setDealForm({ title: "", amount: "", customerId: "" });
    }
  };

  const handleStageChange = async (dealId: string, newStage: string) => {
    const res = await fetch("/api/deals", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: dealId, stage: newStage }),
    });
    if (res.ok) {
      setDeals(prev => prev.map(d => d.id === dealId ? { ...d, stage: newStage } : d));
    }
  };

  const handleGenerateInvoice = async (deal: { id: string; title: string; amount: number; stage: string }) => {
    const res = await fetch("/api/automation/generate-invoice", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ dealId: deal.id }),
    });
    if (res.ok) {
      alert("Invoice generated successfully!");
    } else {
      const data = await res.json();
      alert(data.error || "Failed to generate invoice");
    }
  };

  const filteredCustomers = customers.filter(c =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">CRM & Sales</h1>
          <p className="text-zinc-500 text-sm mt-1">Manage customers and deals</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowDealModal(true)}
            className="bg-indigo-500 hover:bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
          >
            <Plus className="w-4 h-4" /> New Deal
          </button>
          <button
            onClick={() => setShowCustomerModal(true)}
            className="border border-zinc-700 hover:bg-zinc-800 text-zinc-300 px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
          >
            <Plus className="w-4 h-4" /> Add Customer
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-zinc-800">
        <button
          onClick={() => setActiveTab("customers")}
          className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
            activeTab === "customers"
              ? "border-indigo-500 text-indigo-400"
              : "border-transparent text-zinc-500 hover:text-zinc-300"
          }`}
        >
          <Users className="w-4 h-4" /> Customers
        </button>
        <button
          onClick={() => setActiveTab("kanban")}
          className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
            activeTab === "kanban"
              ? "border-indigo-500 text-indigo-400"
              : "border-transparent text-zinc-500 hover:text-zinc-300"
          }`}
        >
          <KanbanSquare className="w-4 h-4" /> Sales Pipeline
        </button>
      </div>

      {activeTab === "customers" ? (
        <div>
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
            <input
              type="text"
              placeholder="Search customers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full max-w-md pl-10 pr-4 py-2 bg-zinc-900 border border-zinc-800 rounded-lg text-white placeholder:text-zinc-600 focus:outline-none focus:border-indigo-500/50 text-sm"
            />
          </div>

          <div className="bg-zinc-900 rounded-xl border border-zinc-800 overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="border-b border-zinc-800">
                  <th className="text-left py-3 px-4 text-zinc-400 text-xs font-medium uppercase tracking-wider">Name</th>
                  <th className="text-left py-3 px-4 text-zinc-400 text-xs font-medium uppercase tracking-wider">Email</th>
                  <th className="text-left py-3 px-4 text-zinc-400 text-xs font-medium uppercase tracking-wider">Company</th>
                  <th className="text-left py-3 px-4 text-zinc-400 text-xs font-medium uppercase tracking-wider">Status</th>
                  <th className="text-right py-3 px-4 text-zinc-400 text-xs font-medium uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredCustomers.map((customer) => (
                  <tr key={customer.id} className="border-b border-zinc-800/50 hover:bg-zinc-800/30 transition-colors">
                    <td className="py-3 px-4 text-white text-sm">{customer.name}</td>
                    <td className="py-3 px-4 text-zinc-400 text-sm">{customer.email || "—"}</td>
                    <td className="py-3 px-4 text-zinc-400 text-sm">{customer.companyName || "—"}</td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${
                        customer.status === "active" ? "bg-emerald-500/10 text-emerald-400" :
                        customer.status === "lead" ? "bg-blue-500/10 text-blue-400" :
                        "bg-zinc-500/10 text-zinc-400"
                      }`}>
                        {customer.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => deleteCustomer(customer.id)}
                        className="text-zinc-600 hover:text-red-400 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
                {filteredCustomers.length === 0 && (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-zinc-500 text-sm">
                      No customers found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <KanbanBoard
          deals={deals.map(d => ({
            ...d,
            customer: d.customer || undefined,
            assigned: d.assigned || undefined,
          }))}
          onStageChange={handleStageChange}
          onGenerateInvoice={handleGenerateInvoice}
        />
      )}

      {/* Add Customer Modal */}
      <Modal isOpen={showCustomerModal} onClose={() => setShowCustomerModal(false)} title="Add Customer">
        <div className="space-y-4">
          <div>
            <label className="block text-sm text-zinc-300 mb-1">Name</label>
            <input
              type="text"
              value={customerForm.name}
              onChange={(e) => setCustomerForm(p => ({ ...p, name: e.target.value }))}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500/50"
              placeholder="Customer name"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-300 mb-1">Email</label>
            <input
              type="email"
              value={customerForm.email}
              onChange={(e) => setCustomerForm(p => ({ ...p, email: e.target.value }))}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500/50"
              placeholder="email@example.com"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-300 mb-1">Phone</label>
            <input
              type="text"
              value={customerForm.phone}
              onChange={(e) => setCustomerForm(p => ({ ...p, phone: e.target.value }))}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500/50"
              placeholder="+1 234 567 890"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-300 mb-1">Company</label>
            <input
              type="text"
              value={customerForm.companyName}
              onChange={(e) => setCustomerForm(p => ({ ...p, companyName: e.target.value }))}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500/50"
              placeholder="Company name"
            />
          </div>
          <button
            onClick={addCustomer}
            className="w-full bg-indigo-500 hover:bg-indigo-600 text-white py-2 rounded-lg text-sm font-medium transition-colors"
          >
            Add Customer
          </button>
        </div>
      </Modal>

      {/* Add Deal Modal */}
      <Modal isOpen={showDealModal} onClose={() => setShowDealModal(false)} title="New Deal">
        <div className="space-y-4">
          <div>
            <label className="block text-sm text-zinc-300 mb-1">Title</label>
            <input
              type="text"
              value={dealForm.title}
              onChange={(e) => setDealForm(p => ({ ...p, title: e.target.value }))}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500/50"
              placeholder="Deal title"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-300 mb-1">Amount</label>
            <input
              type="number"
              value={dealForm.amount}
              onChange={(e) => setDealForm(p => ({ ...p, amount: e.target.value }))}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500/50"
              placeholder="1000"
            />
          </div>
          <div>
            <label className="block text-sm text-zinc-300 mb-1">Customer</label>
            <select
              value={dealForm.customerId}
              onChange={(e) => setDealForm(p => ({ ...p, customerId: e.target.value }))}
              className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500/50"
            >
              <option value="">No customer</option>
              {customers.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
          <button
            onClick={addDeal}
            className="w-full bg-indigo-500 hover:bg-indigo-600 text-white py-2 rounded-lg text-sm font-medium transition-colors"
          >
            Create Deal
          </button>
        </div>
      </Modal>
    </div>
  );
}
