"use client";

import { useState, useEffect, useCallback } from "react";
import { Modal } from "@/components/ui/modal";
import { Plus, Search, AlertTriangle, Edit3, Trash2 } from "lucide-react";

interface Product {
  id: string;
  sku: string;
  name: string;
  salePrice: number;
  quantityInStock: number;
  reorderLevel: number;
  purchasePrice: number;
}

export default function InventoryPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);

  const [form, setForm] = useState({
    sku: "",
    name: "",
    salePrice: "",
    purchasePrice: "",
    quantityInStock: "",
    reorderLevel: "10",
  });

  const fetchProducts = useCallback(async () => {
    try {
      const res = await fetch("/api/products");
      if (res.ok) setProducts(await res.json());
    } catch (err) {
      console.error("Failed to fetch products", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);

  const resetForm = () => {
    setForm({ sku: "", name: "", salePrice: "", purchasePrice: "", quantityInStock: "", reorderLevel: "10" });
    setEditingProduct(null);
  };

  const openEdit = (product: Product) => {
    setEditingProduct(product);
    setForm({
      sku: product.sku,
      name: product.name,
      salePrice: product.salePrice.toString(),
      purchasePrice: product.purchasePrice.toString(),
      quantityInStock: product.quantityInStock.toString(),
      reorderLevel: product.reorderLevel.toString(),
    });
    setShowModal(true);
  };

  const handleSubmit = async () => {
    if (editingProduct) {
      const res = await fetch("/api/products", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: editingProduct.id,
          name: form.name,
          sku: form.sku,
          salePrice: parseFloat(form.salePrice),
          purchasePrice: parseFloat(form.purchasePrice),
          quantityInStock: parseInt(form.quantityInStock),
          reorderLevel: parseInt(form.reorderLevel),
        }),
      });
      if (res.ok) {
        const updated = await res.json();
        setProducts(prev => prev.map(p => p.id === updated.id ? updated : p));
        setShowModal(false);
        resetForm();
      }
    } else {
      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sku: form.sku,
          name: form.name,
          salePrice: parseFloat(form.salePrice) || 0,
          purchasePrice: parseFloat(form.purchasePrice) || 0,
          quantityInStock: parseInt(form.quantityInStock) || 0,
          reorderLevel: parseInt(form.reorderLevel) || 10,
        }),
      });
      if (res.ok) {
        const newProduct = await res.json();
        setProducts(prev => [...prev, newProduct]);
        setShowModal(false);
        resetForm();
      }
    }
  };

  const deleteProduct = async (id: string) => {
    if (!confirm("Delete this product?")) return;
    const res = await fetch(`/api/products?id=${id}`, { method: "DELETE" });
    if (res.ok) setProducts(prev => prev.filter(p => p.id !== id));
  };

  const filteredProducts = products.filter(p =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.sku.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Inventory</h1>
          <p className="text-zinc-500 text-sm mt-1">Manage your products and stock levels</p>
        </div>
        <button
          onClick={() => { resetForm(); setShowModal(true); }}
          className="bg-indigo-500 hover:bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
        >
          <Plus className="w-4 h-4" /> Add Product
        </button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
        <input
          type="text"
          placeholder="Search products by name or SKU..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full max-w-md pl-10 pr-4 py-2 bg-zinc-900 border border-zinc-800 rounded-lg text-white placeholder:text-zinc-600 focus:outline-none focus:border-indigo-500/50 text-sm"
        />
      </div>

      <div className="bg-zinc-900 rounded-xl border border-zinc-800 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-zinc-800">
              <th className="text-left py-3 px-4 text-zinc-400 text-xs font-medium uppercase tracking-wider">Product</th>
              <th className="text-left py-3 px-4 text-zinc-400 text-xs font-medium uppercase tracking-wider">SKU</th>
              <th className="text-right py-3 px-4 text-zinc-400 text-xs font-medium uppercase tracking-wider">Sale Price</th>
              <th className="text-right py-3 px-4 text-zinc-400 text-xs font-medium uppercase tracking-wider">In Stock</th>
              <th className="text-right py-3 px-4 text-zinc-400 text-xs font-medium uppercase tracking-wider">Reorder At</th>
              <th className="text-right py-3 px-4 text-zinc-400 text-xs font-medium uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredProducts.map((product) => {
              const isLowStock = product.quantityInStock <= product.reorderLevel;
              return (
                <tr key={product.id} className="border-b border-zinc-800/50 hover:bg-zinc-800/30 transition-colors">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <span className="text-white text-sm font-medium">{product.name}</span>
                      {isLowStock && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-500/10 text-red-400 text-[10px] font-medium">
                          <AlertTriangle className="w-3 h-3" /> Low
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-zinc-400 text-sm font-mono">{product.sku}</td>
                  <td className="py-3 px-4 text-zinc-200 text-sm text-right">${product.salePrice.toFixed(2)}</td>
                  <td className={`py-3 px-4 text-sm text-right font-medium ${isLowStock ? "text-red-400" : "text-zinc-200"}`}>
                    {product.quantityInStock}
                  </td>
                  <td className="py-3 px-4 text-zinc-500 text-sm text-right">{product.reorderLevel}</td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button onClick={() => openEdit(product)} className="text-zinc-600 hover:text-indigo-400 transition-colors">
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button onClick={() => deleteProduct(product.id)} className="text-zinc-600 hover:text-red-400 transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {filteredProducts.length === 0 && (
              <tr>
                <td colSpan={6} className="py-8 text-center text-zinc-500 text-sm">
                  No products found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Modal
        isOpen={showModal}
        onClose={() => { setShowModal(false); resetForm(); }}
        title={editingProduct ? "Edit Product" : "Add Product"}
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-zinc-300 mb-1">SKU</label>
              <input
                type="text"
                value={form.sku}
                onChange={(e) => setForm(p => ({ ...p, sku: e.target.value }))}
                className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500/50"
                placeholder="SKU-001"
              />
            </div>
            <div>
              <label className="block text-sm text-zinc-300 mb-1">Name</label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => setForm(p => ({ ...p, name: e.target.value }))}
                className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500/50"
                placeholder="Product name"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-zinc-300 mb-1">Sale Price</label>
              <input
                type="number"
                value={form.salePrice}
                onChange={(e) => setForm(p => ({ ...p, salePrice: e.target.value }))}
                className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500/50"
                placeholder="0.00"
                step="0.01"
              />
            </div>
            <div>
              <label className="block text-sm text-zinc-300 mb-1">Purchase Price</label>
              <input
                type="number"
                value={form.purchasePrice}
                onChange={(e) => setForm(p => ({ ...p, purchasePrice: e.target.value }))}
                className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500/50"
                placeholder="0.00"
                step="0.01"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-zinc-300 mb-1">Quantity in Stock</label>
              <input
                type="number"
                value={form.quantityInStock}
                onChange={(e) => setForm(p => ({ ...p, quantityInStock: e.target.value }))}
                className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500/50"
                placeholder="0"
              />
            </div>
            <div>
              <label className="block text-sm text-zinc-300 mb-1">Reorder Level</label>
              <input
                type="number"
                value={form.reorderLevel}
                onChange={(e) => setForm(p => ({ ...p, reorderLevel: e.target.value }))}
                className="w-full px-3 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white text-sm focus:outline-none focus:border-indigo-500/50"
                placeholder="10"
              />
            </div>
          </div>
          <button
            onClick={handleSubmit}
            className="w-full bg-indigo-500 hover:bg-indigo-600 text-white py-2 rounded-lg text-sm font-medium transition-colors"
          >
            {editingProduct ? "Update Product" : "Add Product"}
          </button>
        </div>
      </Modal>
    </div>
  );
}
