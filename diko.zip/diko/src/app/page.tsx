import Link from "next/link";
import {
  ArrowRight,
  Users,
  Package,
  FileText,
  BarChart3,
  Brain,
  Building2,
  Check,
  Star,
  Shield,
  Zap,
} from "lucide-react";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-zinc-950">
      {/* Header */}
      <header className="border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
              <Building2 className="w-4 h-4 text-white" />
            </div>
            <span className="text-xl font-bold text-white">diko</span>
          </div>
          <div className="flex items-center gap-4">
            <Link
              href="/login"
              className="text-zinc-400 hover:text-white transition-colors text-sm font-medium"
            >
              Sign In
            </Link>
            <Link
              href="/register"
              className="bg-indigo-500 hover:bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
            >
              Get Started
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-indigo-500/5 via-transparent to-transparent" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32 relative">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-sm mb-6">
              <Zap className="w-4 h-4" /> AI-Powered Business Platform
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Your entire business,{" "}
              <span className="bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
                on one platform.
              </span>
            </h1>
            <p className="text-lg text-zinc-400 mb-8 max-w-2xl mx-auto">
              From leads to invoices, manage every part of your business with one
              beautiful, intelligent platform. No complexity, no hidden costs.
            </p>
            <div className="flex items-center justify-center gap-4">
              <Link
                href="/register"
                className="bg-indigo-500 hover:bg-indigo-600 text-white px-6 py-3 rounded-xl text-sm font-semibold transition-all hover:shadow-lg hover:shadow-indigo-500/25 inline-flex items-center gap-2"
              >
                Get Started Free <ArrowRight className="w-4 h-4" />
              </Link>
              <a
                href="#features"
                className="border border-zinc-700 text-zinc-300 hover:bg-zinc-800 px-6 py-3 rounded-xl text-sm font-semibold transition-colors inline-block"
              >
                Learn More
              </a>
            </div>
            <p className="text-zinc-600 text-sm mt-4">No credit card required · Free 14-day trial</p>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="border-y border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-3 gap-8 text-center">
            {[
              { value: "10x", label: "Faster Workflows" },
              { value: "99.9%", label: "Uptime Guarantee" },
              { value: "50k+", label: "Active Businesses" },
            ].map((stat) => (
              <div key={stat.label}>
                <p className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
                  {stat.value}
                </p>
                <p className="text-zinc-500 text-sm mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Everything you need to grow
            </h2>
            <p className="text-zinc-400 max-w-2xl mx-auto">
              Powerful tools that work together seamlessly. No more juggling
              between different apps.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: Users,
                title: "CRM & Sales",
                description:
                  "Track leads, manage pipelines with drag-and-drop Kanban, and close deals faster.",
              },
              {
                icon: Package,
                title: "Inventory Management",
                description:
                  "Real-time stock tracking, low-stock alerts, and automated reorder suggestions.",
              },
              {
                icon: FileText,
                title: "Smart Invoicing",
                description:
                  "Create invoices in seconds, automate billing, and get paid faster.",
              },
              {
                icon: BarChart3,
                title: "Analytics Dashboard",
                description:
                  "Real-time insights into your revenue, sales pipeline, and business performance.",
              },
              {
                icon: Brain,
                title: "AI-Powered Insights",
                description:
                  "Smart predictions and recommendations to help you make better decisions.",
              },
              {
                icon: Star,
                title: "Team Collaboration",
                description:
                  "Assign tasks, track activities, and keep your team aligned.",
              },
            ].map((feature) => {
              const Icon = feature.icon;
              return (
                <div
                  key={feature.title}
                  className="p-6 rounded-2xl border border-zinc-800 bg-zinc-900/50 hover:bg-zinc-900 hover:border-zinc-700 transition-all group"
                >
                  <div className="w-12 h-12 rounded-xl bg-indigo-500/10 flex items-center justify-center mb-4 group-hover:bg-indigo-500/20 transition-colors">
                    <Icon className="w-6 h-6 text-indigo-400" />
                  </div>
                  <h3 className="text-white font-semibold mb-2">{feature.title}</h3>
                  <p className="text-zinc-400 text-sm leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-24 bg-zinc-900/30 border-t border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Simple, transparent pricing
            </h2>
            <p className="text-zinc-400 max-w-2xl mx-auto">
              No hidden fees. No surprises. Scale as you grow.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              {
                name: "Starter",
                price: "$29",
                description: "Perfect for small teams getting started",
                features: ["Up to 5 users", "CRM & Sales pipeline", "Basic inventory", "Email support"],
              },
              {
                name: "Business",
                price: "$79",
                description: "For growing businesses with advanced needs",
                features: ["Up to 25 users", "Everything in Starter", "Advanced inventory", "Smart invoicing", "Analytics & reports", "Priority support"],
                popular: true,
              },
              {
                name: "Enterprise",
                price: "Custom",
                description: "For large organizations with custom requirements",
                features: ["Unlimited users", "Everything in Business", "AI-powered insights", "Custom integrations", "Dedicated support", "SLA guarantee"],
              },
            ].map((tier) => (
              <div
                key={tier.name}
                className={`relative p-6 rounded-2xl border ${
                  tier.popular
                    ? "border-indigo-500/50 bg-indigo-500/5"
                    : "border-zinc-800 bg-zinc-900/50"
                }`}
              >
                {tier.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-indigo-500 rounded-full text-xs font-medium text-white">
                    Most Popular
                  </div>
                )}
                <h3 className="text-white text-lg font-semibold mb-1">{tier.name}</h3>
                <p className="text-zinc-500 text-sm mb-4">{tier.description}</p>
                <div className="mb-6">
                  <span className="text-4xl font-bold text-white">{tier.price}</span>
                  {tier.price !== "Custom" && (
                    <span className="text-zinc-500 text-sm ml-1">/month</span>
                  )}
                </div>
                <ul className="space-y-3 mb-8">
                  {tier.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm text-zinc-300">
                      <Check className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Link
                  href="/register"
                  className={`block text-center w-full py-2.5 rounded-lg text-sm font-semibold transition-all ${
                    tier.popular
                      ? "bg-indigo-500 hover:bg-indigo-600 text-white"
                      : "border border-zinc-700 text-zinc-300 hover:bg-zinc-800"
                  }`}
                >
                  Get Started
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-zinc-800 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                <Building2 className="w-4 h-4 text-white" />
              </div>
              <span className="text-lg font-bold text-white">diko</span>
            </div>
            <p className="text-zinc-500 text-sm">
              © 2026 diko. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
