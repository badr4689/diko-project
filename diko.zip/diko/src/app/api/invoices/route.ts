import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";

function generateInvoiceNumber(): string {
  const now = new Date();
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, "0");
  const rand = String(Math.floor(1000 + Math.random() * 9000));
  return `INV-${yyyy}${mm}-${rand}`;
}

export async function GET() {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const invoices = await prisma.invoice.findMany({
      where: { companyId: session.user.companyId },
      include: {
        customer: { select: { id: true, name: true } },
        _count: { select: { items: true } },
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json(invoices);
  } catch (error) {
    console.error("GET /api/invoices error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { customerId, dueDate, taxRate, items } = await request.json();

    if (!customerId || !dueDate || !items || !items.length) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    const customer = await prisma.customer.findUnique({ where: { id: customerId } });
    if (!customer || customer.companyId !== session.user.companyId) {
      return NextResponse.json({ error: "Invalid customer" }, { status: 400 });
    }

    for (const item of items) {
      if (item.productId) {
        const product = await prisma.product.findUnique({ where: { id: item.productId } });
        if (!product || product.companyId !== session.user.companyId) {
          return NextResponse.json({ error: `Invalid product ${item.productId}` }, { status: 400 });
        }
      }
    }

    const subtotal = items.reduce((sum: number, item: { quantity: number; unitPrice: number }) => {
      return sum + item.quantity * item.unitPrice;
    }, 0);

    const rate = taxRate ?? 0;
    const totalAmount = subtotal + (subtotal * rate) / 100;
    const invoiceNumber = generateInvoiceNumber();

    const invoice = await prisma.$transaction(async (tx) => {
      const inv = await tx.invoice.create({
        data: {
          companyId: session.user.companyId,
          customerId,
          invoiceNumber,
          dueDate: new Date(dueDate),
          subtotal,
          taxRate: rate,
          totalAmount,
          status: "draft",
          items: {
            create: items.map((item: { productId?: string; quantity: number; unitPrice: number }) => ({
              productId: item.productId || null,
              quantity: item.quantity,
              unitPrice: item.unitPrice,
              totalPrice: item.quantity * item.unitPrice,
            })),
          },
        },
        include: { items: true },
      });

      return inv;
    });

    await prisma.activity.create({
      data: {
        companyId: session.user.companyId,
        userId: session.user.id,
        action: "created",
        entity: "invoice",
        entityId: invoice.id,
        details: `Created invoice ${invoice.invoiceNumber} for $${totalAmount.toFixed(2)}`,
      },
    });

    return NextResponse.json(invoice, { status: 201 });
  } catch (error) {
    console.error("POST /api/invoices error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id, status } = await request.json();

    if (!id || !status) {
      return NextResponse.json({ error: "ID and status are required" }, { status: 400 });
    }

    const invoice = await prisma.invoice.findUnique({
      where: { id },
      include: { items: true },
    });

    if (!invoice) {
      return NextResponse.json({ error: "Invoice not found" }, { status: 404 });
    }

    if (invoice.companyId !== session.user.companyId) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    if (status === "paid" && invoice.status !== "paid") {
      await prisma.$transaction(async (tx) => {
        for (const item of invoice.items) {
          if (item.productId) {
            await tx.product.update({
              where: { id: item.productId },
              data: { quantityInStock: { decrement: item.quantity } },
            });
          }
        }

        await tx.invoice.update({
          where: { id },
          data: { status },
        });
      });
    } else {
      await prisma.invoice.update({
        where: { id },
        data: { status },
      });
    }

    await prisma.activity.create({
      data: {
        companyId: session.user.companyId,
        userId: session.user.id,
        action: "updated",
        entity: "invoice",
        entityId: id,
        details: `Updated invoice ${invoice.invoiceNumber} status to ${status}`,
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("PATCH /api/invoices error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "Invoice ID is required" }, { status: 400 });
    }

    const invoice = await prisma.invoice.findUnique({ where: { id } });

    if (!invoice) {
      return NextResponse.json({ error: "Invoice not found" }, { status: 404 });
    }

    if (invoice.companyId !== session.user.companyId) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    await prisma.invoice.delete({ where: { id } });

    await prisma.activity.create({
      data: {
        companyId: session.user.companyId,
        userId: session.user.id,
        action: "deleted",
        entity: "invoice",
        entityId: id,
        details: `Deleted invoice ${invoice.invoiceNumber}`,
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/invoices error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
