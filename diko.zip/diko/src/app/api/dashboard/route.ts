import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";

export async function GET() {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const companyId = session.user.companyId;
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfNextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);

    const monthlyRevenueResult = await prisma.invoice.aggregate({
      where: {
        companyId,
        status: "paid",
        createdAt: { gte: startOfMonth, lt: startOfNextMonth },
      },
      _sum: { totalAmount: true },
    });

    const monthlyRevenue = monthlyRevenueResult._sum.totalAmount ?? 0;

    const activeDeals = await prisma.deal.count({
      where: {
        companyId,
        NOT: { stage: { in: ["won", "lost"] } },
      },
    });

    const lowStockItems = await prisma.product.count({
      where: {
        companyId,
        quantityInStock: { lte: prisma.product.fields.reorderLevel },
      },
    });

    const pendingInvoicesResult = await prisma.invoice.aggregate({
      where: {
        companyId,
        status: { in: ["sent", "overdue"] },
      },
      _sum: { totalAmount: true },
    });

    const pendingInvoices = pendingInvoicesResult._sum.totalAmount ?? 0;

    const revenueData = [];
    for (let i = 5; i >= 0; i--) {
      const m = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const mStart = new Date(m.getFullYear(), m.getMonth(), 1);
      const mEnd = new Date(m.getFullYear(), m.getMonth() + 1, 1);

      const result = await prisma.invoice.aggregate({
        where: {
          companyId,
          status: "paid",
          createdAt: { gte: mStart, lt: mEnd },
        },
        _sum: { totalAmount: true },
      });

      revenueData.push({
        month: mStart.toLocaleString("default", { month: "short" }),
        revenue: result._sum.totalAmount ?? 0,
      });
    }

    const recentActivities = await prisma.activity.findMany({
      where: { companyId },
      orderBy: { createdAt: "desc" },
      take: 5,
    });

    return NextResponse.json({
      monthlyRevenue,
      activeDeals,
      lowStockItems,
      pendingInvoices,
      revenueData,
      recentActivities,
    });
  } catch (error) {
    console.error("GET /api/dashboard error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
