import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";

export async function POST() {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const now = new Date();

    const overdueInvoices = await prisma.invoice.findMany({
      where: {
        companyId: session.user.companyId,
        status: "sent",
        dueDate: { lt: now },
      },
    });

    if (overdueInvoices.length === 0) {
      return NextResponse.json({ updated: 0 });
    }

    const ids = overdueInvoices.map((inv) => inv.id);

    await prisma.invoice.updateMany({
      where: { id: { in: ids } },
      data: { status: "overdue" },
    });

    await prisma.activity.createMany({
      data: overdueInvoices.map((inv) => ({
        companyId: session.user.companyId,
        userId: session.user.id,
        action: "automation",
        entity: "invoice",
        entityId: inv.id,
        details: `Marked invoice ${inv.invoiceNumber} as overdue`,
      })),
    });

    return NextResponse.json({ updated: overdueInvoices.length });
  } catch (error) {
    console.error("POST /api/automation/check-overdue error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
