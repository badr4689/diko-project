import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";

export async function POST(request: Request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { dealId } = await request.json();

    if (!dealId) {
      return NextResponse.json({ error: "Deal ID is required" }, { status: 400 });
    }

    const deal = await prisma.deal.findUnique({
      where: { id: dealId },
      include: { customer: { select: { id: true, name: true } } },
    });

    if (!deal) {
      return NextResponse.json({ error: "Deal not found" }, { status: 404 });
    }

    if (deal.companyId !== session.user.companyId) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    if (deal.stage !== "won") {
      return NextResponse.json({ error: "Deal is not won" }, { status: 400 });
    }

    const now = new Date();
    const dueDate = new Date(now);
    dueDate.setDate(dueDate.getDate() + 30);

    const rand = String(Math.floor(1000 + Math.random() * 9000));
    const invoiceNumber = `INV-WON-${rand}`;

    const invoice = await prisma.$transaction(async (tx) => {
      const inv = await tx.invoice.create({
        data: {
          companyId: session.user.companyId,
          customerId: deal.customerId,
          invoiceNumber,
          dueDate,
          subtotal: deal.amount,
          taxRate: 0,
          totalAmount: deal.amount,
          status: "draft",
          items: {
            create: [
              {
                productId: null,
                quantity: 1,
                unitPrice: deal.amount,
                totalPrice: deal.amount,
              },
            ],
          },
        },
        include: { items: true },
      });

      return inv;
    });

    await prisma.activity.create({
      data: {
        companyId: session.user.companyId,
        userId: session.user.id,
        action: "created",
        entity: "invoice",
        entityId: invoice.id,
        details: `Generated invoice ${invoiceNumber} from won deal ${deal.title}`,
      },
    });

    await prisma.activity.create({
      data: {
        companyId: session.user.companyId,
        userId: session.user.id,
        action: "automation",
        entity: "deal",
        entityId: dealId,
        details: `Auto-generated invoice ${invoiceNumber} for won deal ${deal.title}`,
      },
    });

    return NextResponse.json(invoice, { status: 201 });
  } catch (error) {
    console.error("POST /api/automation/generate-invoice error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
