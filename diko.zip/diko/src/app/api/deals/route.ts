import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";

export async function GET() {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const deals = await prisma.deal.findMany({
      where: { companyId: session.user.companyId },
      include: {
        customer: { select: { name: true } },
        assigned: { select: { fullName: true } },
      },
      orderBy: { updatedAt: "desc" },
    });

    return NextResponse.json(deals);
  } catch (error) {
    console.error("GET /api/deals error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { title, amount, customerId, stage, assignedTo } = await request.json();

    if (!title) {
      return NextResponse.json({ error: "Title is required" }, { status: 400 });
    }

    if (customerId) {
      const customer = await prisma.customer.findUnique({ where: { id: customerId } });
      if (!customer || customer.companyId !== session.user.companyId) {
        return NextResponse.json({ error: "Invalid customer" }, { status: 400 });
      }
    }

    if (assignedTo) {
      const user = await prisma.user.findUnique({ where: { id: assignedTo } });
      if (!user || user.companyId !== session.user.companyId) {
        return NextResponse.json({ error: "Invalid assigned user" }, { status: 400 });
      }
    }

    const deal = await prisma.deal.create({
      data: {
        companyId: session.user.companyId,
        title,
        amount: amount ?? 0,
        customerId,
        stage: stage ?? "new",
        assignedTo,
      },
    });

    await prisma.activity.create({
      data: {
        companyId: session.user.companyId,
        userId: session.user.id,
        action: "created",
        entity: "deal",
        entityId: deal.id,
        details: `Created deal ${deal.title} in stage ${deal.stage}`,
      },
    });

    return NextResponse.json(deal, { status: 201 });
  } catch (error) {
    console.error("POST /api/deals error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id, stage } = await request.json();

    if (!id || !stage) {
      return NextResponse.json({ error: "ID and stage are required" }, { status: 400 });
    }

    const deal = await prisma.deal.findUnique({ where: { id } });

    if (!deal) {
      return NextResponse.json({ error: "Deal not found" }, { status: 404 });
    }

    if (deal.companyId !== session.user.companyId) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const updated = await prisma.deal.update({
      where: { id },
      data: { stage, updatedAt: new Date() },
    });

    await prisma.activity.create({
      data: {
        companyId: session.user.companyId,
        userId: session.user.id,
        action: "updated",
        entity: "deal",
        entityId: id,
        details: `Moved deal ${updated.title} to stage ${stage}`,
      },
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error("PATCH /api/deals error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "Deal ID is required" }, { status: 400 });
    }

    const deal = await prisma.deal.findUnique({ where: { id } });

    if (!deal) {
      return NextResponse.json({ error: "Deal not found" }, { status: 404 });
    }

    if (deal.companyId !== session.user.companyId) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    await prisma.deal.delete({ where: { id } });

    await prisma.activity.create({
      data: {
        companyId: session.user.companyId,
        userId: session.user.id,
        action: "deleted",
        entity: "deal",
        entityId: id,
        details: `Deleted deal ${deal.title}`,
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/deals error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
