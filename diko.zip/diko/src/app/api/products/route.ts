import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";

export async function GET() {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const products = await prisma.product.findMany({
      where: { companyId: session.user.companyId },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json(products);
  } catch (error) {
    console.error("GET /api/products error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { sku, name, description, purchasePrice, salePrice, quantityInStock, reorderLevel } = await request.json();

    if (!sku || !name) {
      return NextResponse.json({ error: "SKU and name are required" }, { status: 400 });
    }

    const existing = await prisma.product.findUnique({
      where: { companyId_sku: { companyId: session.user.companyId, sku } },
    });

    if (existing) {
      return NextResponse.json({ error: "SKU already exists for this company" }, { status: 409 });
    }

    const product = await prisma.product.create({
      data: {
        companyId: session.user.companyId,
        sku,
        name,
        description,
        purchasePrice: purchasePrice ?? 0,
        salePrice: salePrice ?? 0,
        quantityInStock: quantityInStock ?? 0,
        reorderLevel: reorderLevel ?? 10,
      },
    });

    await prisma.activity.create({
      data: {
        companyId: session.user.companyId,
        userId: session.user.id,
        action: "created",
        entity: "product",
        entityId: product.id,
        details: `Created product ${product.name} (${product.sku})`,
      },
    });

    return NextResponse.json(product, { status: 201 });
  } catch (error) {
    console.error("POST /api/products error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id, quantityInStock, salePrice, name, sku, reorderLevel, purchasePrice } = await request.json();

    if (!id) {
      return NextResponse.json({ error: "Product ID is required" }, { status: 400 });
    }

    const product = await prisma.product.findUnique({ where: { id } });

    if (!product) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    if (product.companyId !== session.user.companyId) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const updated = await prisma.product.update({
      where: { id },
      data: {
        ...(quantityInStock !== undefined && { quantityInStock }),
        ...(salePrice !== undefined && { salePrice }),
        ...(name !== undefined && { name }),
        ...(sku !== undefined && { sku }),
        ...(reorderLevel !== undefined && { reorderLevel }),
        ...(purchasePrice !== undefined && { purchasePrice }),
      },
    });

    await prisma.activity.create({
      data: {
        companyId: session.user.companyId,
        userId: session.user.id,
        action: "updated",
        entity: "product",
        entityId: id,
        details: `Updated product ${updated.name}`,
      },
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error("PUT /api/products error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "Product ID is required" }, { status: 400 });
    }

    const product = await prisma.product.findUnique({ where: { id } });

    if (!product) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    if (product.companyId !== session.user.companyId) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    await prisma.product.delete({ where: { id } });

    await prisma.activity.create({
      data: {
        companyId: session.user.companyId,
        userId: session.user.id,
        action: "deleted",
        entity: "product",
        entityId: id,
        details: `Deleted product ${product.name} (${product.sku})`,
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/products error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
