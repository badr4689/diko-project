import { NextResponse } from "next/server";
import { hash } from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";

export async function POST(request: Request) {
  try {
    const { companyName, email, password, fullName } = await request.json();

    if (!companyName || !email || !password || !fullName) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 }
      );
    }

    const existingUser = await prisma.user.findUnique({ where: { email } });
    if (existingUser) {
      return NextResponse.json(
        { error: "Email already in use" },
        { status: 409 }
      );
    }

    const passwordHash = await hash(password, 12);

    const company = await prisma.company.create({
      data: { companyName },
    });

    const user = await prisma.user.create({
      data: {
        companyId: company.id,
        fullName,
        email,
        passwordHash,
        role: "admin",
      },
    });

    return NextResponse.json(
      {
        company: { id: company.id, companyName: company.companyName },
        user: { id: user.id, fullName: user.fullName, email: user.email, role: user.role },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("POST /api/companies error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function GET() {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const company = await prisma.company.findUnique({
      where: { id: session.user.companyId },
      include: { _count: { select: { users: true, customers: true, products: true, deals: true, invoices: true } } },
    });

    if (!company) {
      return NextResponse.json({ error: "Company not found" }, { status: 404 });
    }

    return NextResponse.json(company);
  } catch (error) {
    console.error("GET /api/companies error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
